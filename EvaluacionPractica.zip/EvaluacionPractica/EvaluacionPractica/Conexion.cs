﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace EvaluacionPractica
{
    class Conexion
    {
        public static SqlConnection conexion()
        {
            string servidor = "DESKTOP-L0OUQF7\\SQLSERVER";
            string bd = "Practica";
            string usuario = "sa";
            string password = "Miguelong97";

            String cadenaConexion = "server=" + servidor + " ; database=" + bd + " ; integrated security = true; user id = " + usuario + "; password = " + password + "";
             try
            {
                SqlConnection conexionBD = new SqlConnection(cadenaConexion);
                
                return conexionBD;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error" + ex.Message);
                return null;
            }
        }
    }
}
