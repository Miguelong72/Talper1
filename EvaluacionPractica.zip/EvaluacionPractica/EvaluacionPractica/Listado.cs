﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EvaluacionPractica
{
    public partial class Listado : Form
    {
        public Listado()
        {
            InitializeComponent();
        }
        
        private DataTable Source()
        {

            SqlConnection conectar = Conexion.conexion();
            conectar.Open();

            SqlCommand cmd = conectar.CreateCommand();

            cmd.CommandType = CommandType.Text;
            //using (Model.PracticaEntities3 db = new Model.PracticaEntities3())
            //{
            //    var lista = from d in db.documentos select new { d.nombre };
            //    dataGridView2.DataSource = lista.ToList();
            //}
            cmd.CommandText = "select nombre,apPaterno,apMaterno,estatus from Prospectos";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            conectar.Close();
            return dt;


        }
        private DataTable Source2()
        {

            SqlConnection conectar = Conexion.conexion();
            conectar.Open();

            SqlCommand cmd = conectar.CreateCommand();

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select Id,rfcProspectos, nombre, realname FROM documentos where rfcProspectos= '" + txtRFC.Text + "'";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView2.DataSource = dt;
            conectar.Close();
            return dt;


        }
        private void Listado_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Source();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            txtNombre.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            SqlConnection conectar = Conexion.conexion();
            SqlCommand cmd = new SqlCommand("select * from Prospectos where nombre = '"+ txtNombre.Text + "'", conectar);
            conectar.Open();

            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                
                txtNombre.Text = rd["nombre"].ToString();
                txtApPaterno.Text  = rd["apPaterno"].ToString();
                txtApMaterno.Text = rd["apMaterno"].ToString();
                txtCalle.Text = rd["calle"].ToString();
                txtNumero.Text = rd["numero"].ToString();
                txtColonia.Text = rd["colonia"].ToString();
                txtTelefono.Text = rd["telefono"].ToString();
                txtCodigo.Text = rd["codigo_postal"].ToString();
                txtRFC.Text = rd["rfc"].ToString();
                txtEstatus.Text = rd["estatus"].ToString();
                txtObservaciones.Text = rd["observaciones"].ToString();

            }
            dataGridView2.DataSource = Source2();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridView2.Rows.Count > 0)
                {
                    // txtNombre.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                    //var id = dataGridView2.CurrentRow.Cells[0].Value.ToString();
                  int id = int.Parse(dataGridView2.Rows[dataGridView2.CurrentRow.Index].Cells[0].Value.ToString());

                    using (Model.PracticaEntities3 db = new Model.PracticaEntities3())
                    {
                        var document = db.documentos.Find(id);

                        string path = AppDomain.CurrentDomain.BaseDirectory;
                        string folder = path + "/temp/";
                        string fullFilePath = folder + document.Id;

                        if (!Directory.Exists(folder))
                            Directory.CreateDirectory(folder);

                        if (File.Exists(fullFilePath))
                            File.Delete(fullFilePath);

                        File.WriteAllBytes(fullFilePath, document.doc);

                        Process.Start(fullFilePath);
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrio un error: " + ex.Message);
            }
        }
    }
}
