﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EvaluacionPractica
{
    public partial class Evaluacion : Form
    {
        public Evaluacion()
        {
            InitializeComponent();
        }
        
        private DataTable Source()
        {

            SqlConnection conectar = Conexion.conexion();
            conectar.Open();

            SqlCommand cmd = conectar.CreateCommand();

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM Prospectos";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            conectar.Close();
            return dt;


        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtNombre.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString(); 
            txtApPaterno.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString(); 
            txtApMaterno.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString(); 
            txtCalle.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString(); 
            txtNumero.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            txtColonia.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            txtTelefono.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            txtCodigo.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            txtRFC.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            txtEstatus.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            txtObservaciones.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
        }

        private void Evaluacion_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = Source();
        }

        private void button3_Click(object sender, EventArgs e)
        {
                
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String nombre = txtNombre.Text;

            string sql = "UPDATE Prospectos SET  estatus= 'Aceptado' WHERE nombre= '" + nombre + "'";
            SqlConnection conectar = Conexion.conexion();
            conectar.Open();

            try
            {
                SqlCommand comando = new SqlCommand(sql, conectar);
                comando.ExecuteNonQuery();
                MessageBox.Show("Prospecto Actualizado");
                dataGridView1.DataSource = Source();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al Modificar" + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtObservaciones.Enabled = true;
            String nombre = txtNombre.Text;

            string sql = "UPDATE Prospectos SET  estatus= 'Rechazado' WHERE nombre= '" + nombre + "'";
            SqlConnection conectar = Conexion.conexion();
            conectar.Open();
            

            try
            {
                    SqlCommand comando = new SqlCommand(sql, conectar);
                    comando.ExecuteNonQuery();
                    MessageBox.Show("Asegurece de Agregar los Motivos del Rechazo");
                    dataGridView1.DataSource = Source();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al Modificar" + ex.Message);
            }
        }

        private void txtEnviar_Click(object sender, EventArgs e)
        {
            String nombre = txtNombre.Text;
            String observaciones = txtObservaciones.Text;

            string sql = "UPDATE Prospectos SET observaciones= '" + txtObservaciones.Text + "'WHERE nombre= '" + nombre + "'";
            SqlConnection conectar = Conexion.conexion();
            conectar.Open();
            try
            {
                SqlCommand comando = new SqlCommand(sql, conectar);
                comando.ExecuteNonQuery();
                MessageBox.Show("Observaciones del Prospecto Actualizado");
                dataGridView1.DataSource = Source();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al Modificar" + ex.Message);
            }
        }
    }
}
