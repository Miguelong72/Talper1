﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EvaluacionPractica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e) { }

        private void Form1_Load(object sender, EventArgs e)
        {
            Conexion cn = new Conexion();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Prospecto p = new Prospecto();
            p.ShowDialog();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Evaluacion ev = new Evaluacion();
            ev.ShowDialog();
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Listado l = new Listado();
            l.ShowDialog();

        }
    }
}
