﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Diagnostics;

namespace EvaluacionPractica
{
    public partial class Prospecto : Form
    {
        public Prospecto()
        {
            InitializeComponent();
        }
        
        private DataTable Source()
        {

            SqlConnection conectar = Conexion.conexion();
            conectar.Open();

            SqlCommand cmd = conectar.CreateCommand();

            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM Prospectos";
            cmd.ExecuteNonQuery();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            conectar.Close();
            return dt;


        }
        private void Prospecto_Load(object sender, EventArgs e)
        {
            //refresh();
            dataGridView1.DataSource = Source();
        }
        SqlConnection conectar = Conexion.conexion();
        private void button3_Click(object sender, EventArgs e)
        {
            if (txtTitulo.Text.Trim().Equals("") || txtDocumento.Text.Trim().Equals(""))
            {
                MessageBox.Show("El nombre es obligatorio");
                return;
            }
            byte[] file = null;
            Stream myStream = openFileDialog1.OpenFile();
            using (MemoryStream ms = new MemoryStream())
            {
                myStream.CopyTo(ms);
                file = ms.ToArray();
            }
            using(Model.PracticaEntities3 db = new Model.PracticaEntities3())
            {
               Model.documentos document = new Model.documentos();
                document.nombre = txtTitulo.Text.Trim();
                document.rfcProspectos = txtRFC.Text.Trim();
                document.doc = file;
                document.realName = openFileDialog1.SafeFileName;

                db.documentos.Add(document);
                db.SaveChanges();
                
                //refresh();
            }
            
        }
        //private void refresh()
        //{
        //    using (Model.PracticaEntities3 db = new Model.PracticaEntities3())
        //    {
        //        var lista = from d in db.documentos select new { d.nombre};
        //        dataGridView2.DataSource = lista.ToList();
        //    }  
        //}
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "Todos los archivos (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtDocumento.Text = openFileDialog1.FileName;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            DialogResult Opcion;
            Opcion = MessageBox.Show("Saldrá de la pantalla de captura de prospectos, ningún dato será guardado", "Advertencia", MessageBoxButtons.OKCancel);
            if (Opcion == DialogResult.OK)
            {
                this.Close();
            }
            if (Opcion == DialogResult.No)
            {
                MessageBox.Show("Continue");
            }
        }
        
        private void btnCargar_Click(object sender, EventArgs e)
        {
           
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtNombre.Text) || String.IsNullOrEmpty(txtApPaterno.Text) || String.IsNullOrEmpty(txtApMaterno.Text) || String.IsNullOrEmpty(txtCalle.Text) || String.IsNullOrEmpty(txtNumero.Text) || String.IsNullOrEmpty(txtColonia.Text) || String.IsNullOrEmpty(txtTelefono.Text) || String.IsNullOrEmpty(txtCodigo.Text) || String.IsNullOrEmpty(txtRFC.Text))
            {
                MessageBox.Show("Por favor asegurese de llenar todo los campos");
            }
            else
            {
                DataSet set = new DataSet();

                String nombre = txtNombre.Text;
                String ApPaterno = txtApPaterno.Text;
                String ApMaterno = txtApMaterno.Text;
                String calle = txtCalle.Text;
                String numero = txtNumero.Text;
                String colonia = txtColonia.Text;
                String telefono = txtTelefono.Text;
                String codigo_postal = txtCodigo.Text;
                String rfc = txtRFC.Text;
                String estatus = "Enviada";


                string sql = "INSERT INTO Prospectos (nombre, apPaterno, apMaterno, calle, numero, colonia, telefono, codigo_postal, rfc, estatus) " +
                "VALUES ('" + nombre + "','" + ApPaterno + "','" + ApMaterno + "', '" + calle + "', '" + numero + "', '" + colonia + "', '" + telefono + "', '" + codigo_postal + "', '" + rfc + "', '" + estatus + "')";
                SqlConnection Conectar = Conexion.conexion();
                Conectar.Open();
                try
                {
                    SqlCommand comando = new SqlCommand(sql, Conectar);
                    comando.ExecuteNonQuery();
                    MessageBox.Show("Prospecto Guardado");
                    dataGridView1.DataSource = Source();
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ocurrio un error: " + ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtNombre.Text = "";
            txtApPaterno.Text = "";
            txtApMaterno.Text = "";
            txtCalle.Text = "";
            txtNumero.Text = "";
            txtColonia.Text = "";
            txtTelefono.Text = "";
            txtCodigo.Text = "";
            txtRFC.Text = "";
            txtDocumento.Text = "";
            txtTitulo.Text = "";
        }

        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("SOLO SE ADMITEN NUMEROS", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void txtCodigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("SOLO SE ADMITEN NUMEROS", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void txtNumero_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 32 && e.KeyChar <= 47) || (e.KeyChar >= 58 && e.KeyChar <= 255))
            {
                MessageBox.Show("SOLO SE ADMITEN NUMEROS", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 33 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 208) || (e.KeyChar >= 210 && e.KeyChar <= 240) || (e.KeyChar >= 242 && e.KeyChar <= 255))
            {
                MessageBox.Show("SOLO SE ADMITEN LETRAS", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void txtApPaterno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 33 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 208) || (e.KeyChar >= 210 && e.KeyChar <= 240) || (e.KeyChar >= 242 && e.KeyChar <= 255))
            {
                MessageBox.Show("SOLO SE ADMITEN LETRAS", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }

        private void txtApMaterno_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void txtApMaterno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 33 && e.KeyChar <= 64) || (e.KeyChar >= 91 && e.KeyChar <= 96) || (e.KeyChar >= 123 && e.KeyChar <= 208) || (e.KeyChar >= 210 && e.KeyChar <= 240) || (e.KeyChar >= 242 && e.KeyChar <= 255))
            {
                MessageBox.Show("SOLO SE ADMITEN LETRAS", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
                return;
            }
        }
    }
}
